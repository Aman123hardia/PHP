<?php

function databaseConnection(){
echo 'Hello database call';
}


?>

