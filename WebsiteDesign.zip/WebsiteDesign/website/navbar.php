<div class='container-fluid bg-secondary '  > 
    <nav class="navbar navbar-expand-lg navbar-light ">
            <img src="../images/icon1.png" width="50" height="50" alt="" class="">
            <div class='text-center text-white p-3 ' style='width:100%'><h3>Employee Management System</h3>
          </div>
          <a href="index.php"><img src="../images/backHome.png" width="60" height="60" alt="" class="" style='float:right'></a>
  </nav> 
</div>