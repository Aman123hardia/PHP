<?php $foo=3;  
echo ( $foo == 1 ) ? "1" : (( $foo == 2 ) ? "2" : "other");
 ?>