<div class='container-fluid bg-secondary '  > 
    <nav class="navbar navbar-expand-lg navbar-light ">
      <img src='assets/images/icon1.png' class="img-fluid " width="50" height="50"/>
            <div class='text-center text-white p-3 ' style='width:100%'><h3>Employee Management System</h3>
          </div>
          <a href="index.php"><img src='assets/images/backHome.png' width="70" height="70" alt="" class="" style='float:right'></a>
  </nav> 
</div>